from .base_tank import Tank
from .heavy_tank import HeavyTank
from .light_tank import LightTank
